from rest_framework import viewsets, permissions
from rest_framework.permissions import IsAuthenticated
from accounts.permissions import IsAdminUser, IsRegularUser
from .models import Course, Enrollment
from .serializers import CourseSerializer, EnrollmentSerializer
from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect, get_object_or_404


class CourseViewSet(viewsets.ModelViewSet):
    queryset = Course.objects.all()
    serializer_class = CourseSerializer

    def get_permissions(self):
        if self.action in ['create', 'update', 'partial_update', 'destroy']:
            permission_classes = [IsAuthenticated, IsAdminUser]
        else:
            permission_classes = [IsAuthenticated]
        return [permission() for permission in permission_classes]


@login_required
def course_list(request):
    courses = Course.objects.all()
    return render(request, "courses/course_list.html", {
        "courses": courses
    })



class EnrollmentViewSet(viewsets.ModelViewSet):
    serializer_class = EnrollmentSerializer

    def get_queryset(self):
        return Enrollment.objects.filter(user=self.request.user)

    def get_permissions(self):
        if self.action in ['create']:
            permission_classes = [IsAuthenticated, IsRegularUser]
        else:
            permission_classes = [IsAuthenticated]
        return [permission() for permission in permission_classes]
    

@login_required
def enrolled_courses(request):
    enrollments = Enrollment.objects.filter(user=request.user)

    return render(request, "courses/enrolled_courses.html", {
        "enrollments": enrollments
    })