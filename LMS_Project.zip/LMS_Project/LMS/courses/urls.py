from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import CourseViewSet, EnrollmentViewSet, course_list,enrolled_courses

router = DefaultRouter()
router.register(r'courses', CourseViewSet, basename='courses')
router.register(r'enrollments', EnrollmentViewSet, basename='enrollments')

urlpatterns = [
    path("course-list", course_list, name="course-list"),
    path("enrolled/", enrolled_courses, name="enrolled-courses"),
]
