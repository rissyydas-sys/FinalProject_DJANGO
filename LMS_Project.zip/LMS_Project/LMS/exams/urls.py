from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import ExamViewSet,add_exam, exam_list

router = DefaultRouter()
router.register(r'exams', ExamViewSet, basename='exam')

urlpatterns = [
    path('', include(router.urls)),  # All routes handled automatically
    path('add-exam/', add_exam, name='add-exam'),
    path("exam-list/", exam_list, name="exam-list"),
]
