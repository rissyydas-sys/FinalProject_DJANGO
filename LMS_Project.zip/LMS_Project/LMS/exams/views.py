from rest_framework import viewsets
from accounts.permissions import IsAdminUser
from rest_framework.permissions import IsAuthenticated
from .models import Exam
from django.contrib.auth.decorators import login_required
from .serializers import ExamSerializer

class ExamViewSet(viewsets.ModelViewSet):
    queryset = Exam.objects.all()
    serializer_class = ExamSerializer
    permission_classes = [IsAuthenticated, IsAdminUser]

from django.contrib.auth.decorators import user_passes_test
from django.shortcuts import render, redirect
from .forms import ExamForm

def is_admin(user):
    return user.is_superuser

@user_passes_test(is_admin)
def add_exam(request):
    if request.method == 'POST':
        form = ExamForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('admin_dashboard')
    else:
        form = ExamForm()

    return render(request, 'admin/add_exam.html', {'form': form})

@login_required
def exam_list(request):
    exams = Exam.objects.all()
    return render(request, "exams/exam_list.html", {
        "exams": exams
    })