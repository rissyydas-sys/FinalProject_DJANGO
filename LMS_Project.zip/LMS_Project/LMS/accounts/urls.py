from django.urls import path
from .views import RegisterView, ApproveUserView, user_approvals,add_course, user_login, user_dashboard,user_logout
from rest_framework_simplejwt.views import (
    TokenObtainPairView,
    TokenRefreshView,
)

urlpatterns = [
    path('register/', RegisterView.as_view(), name='register'),
    path('login/', TokenObtainPairView.as_view(), name='login'),
    path('token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
    path('approve-user/<int:pk>/', ApproveUserView.as_view(), name='approve_user'),
    # path('admin-dashboard/', admin_dashboard, name='admin-dashboard'),
    path('user-approvals/', user_approvals, name='user-approvals'),
    path('add-course/', add_course, name='add-course'),
    path("login/", user_login, name="login"),
    path("dashboard/", user_dashboard, name="user-dashboard"),
    path("logout/", user_logout, name="logout"),
]
