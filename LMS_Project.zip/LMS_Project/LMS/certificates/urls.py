from django.contrib import admin
from django.urls import path
from .views import download_certificate

urlpatterns = [
   path('certificate/<int:exam_id>/', download_certificate,
         name='download_certificate'),
]
