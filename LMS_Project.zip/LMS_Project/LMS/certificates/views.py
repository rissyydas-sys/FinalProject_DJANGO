from django.contrib.auth.decorators import login_required
from django.shortcuts import get_object_or_404
from exams.models import Result
from .utils import generate_certificate

@login_required
def download_certificate(request, exam_id):
    result = get_object_or_404(
        Result,
        exam_id=exam_id,
        user=request.user,
        passed=True
    )

    course = result.exam.course
    return generate_certificate(request.user, course)
